﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
<Global.System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1726")> _
Partial Class LoginAdmin
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
      If disposing AndAlso components IsNot Nothing Then
        components.Dispose()
      End If
    Finally
      MyBase.Dispose(disposing)
    End Try
  End Sub
  Friend WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
  Friend WithEvents UsernameLabel As System.Windows.Forms.Label
  Friend WithEvents PasswordLabel As System.Windows.Forms.Label
  Friend WithEvents txtUser As System.Windows.Forms.TextBox
  Friend WithEvents txtPass As System.Windows.Forms.TextBox
  Friend WithEvents btnOk As System.Windows.Forms.Button
  Friend WithEvents btnCancel As System.Windows.Forms.Button

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
    Me.UsernameLabel = New System.Windows.Forms.Label()
    Me.PasswordLabel = New System.Windows.Forms.Label()
    Me.txtUser = New System.Windows.Forms.TextBox()
    Me.txtPass = New System.Windows.Forms.TextBox()
    Me.btnOk = New System.Windows.Forms.Button()
    Me.btnCancel = New System.Windows.Forms.Button()
    Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.Button1 = New System.Windows.Forms.Button()
    CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'UsernameLabel
    '
    Me.UsernameLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.UsernameLabel.Location = New System.Drawing.Point(141, 57)
    Me.UsernameLabel.Name = "UsernameLabel"
    Me.UsernameLabel.Size = New System.Drawing.Size(220, 23)
    Me.UsernameLabel.TabIndex = 0
    Me.UsernameLabel.Text = "&User name"
    Me.UsernameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
    '
    'PasswordLabel
    '
    Me.PasswordLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.PasswordLabel.Location = New System.Drawing.Point(141, 106)
    Me.PasswordLabel.Name = "PasswordLabel"
    Me.PasswordLabel.Size = New System.Drawing.Size(220, 23)
    Me.PasswordLabel.TabIndex = 2
    Me.PasswordLabel.Text = "&Password"
    Me.PasswordLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
    '
    'txtUser
    '
    Me.txtUser.Location = New System.Drawing.Point(144, 83)
    Me.txtUser.Name = "txtUser"
    Me.txtUser.Size = New System.Drawing.Size(220, 20)
    Me.txtUser.TabIndex = 1
    '
    'txtPass
    '
    Me.txtPass.Location = New System.Drawing.Point(144, 132)
    Me.txtPass.Name = "txtPass"
    Me.txtPass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
    Me.txtPass.Size = New System.Drawing.Size(220, 20)
    Me.txtPass.TabIndex = 3
    '
    'btnOk
    '
    Me.btnOk.Cursor = System.Windows.Forms.Cursors.Arrow
    Me.btnOk.Location = New System.Drawing.Point(144, 179)
    Me.btnOk.Name = "btnOk"
    Me.btnOk.Size = New System.Drawing.Size(94, 23)
    Me.btnOk.TabIndex = 4
    Me.btnOk.Text = "&OK"
    '
    'btnCancel
    '
    Me.btnCancel.Cursor = System.Windows.Forms.Cursors.Default
    Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.btnCancel.Location = New System.Drawing.Point(258, 179)
    Me.btnCancel.Name = "btnCancel"
    Me.btnCancel.Size = New System.Drawing.Size(94, 23)
    Me.btnCancel.TabIndex = 5
    Me.btnCancel.Text = "&Cancel"
    '
    'LogoPictureBox
    '
    Me.LogoPictureBox.Image = Global.db_prac.My.Resources.Resources.bloodV
    Me.LogoPictureBox.Location = New System.Drawing.Point(0, 0)
    Me.LogoPictureBox.Name = "LogoPictureBox"
    Me.LogoPictureBox.Size = New System.Drawing.Size(113, 262)
    Me.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
    Me.LogoPictureBox.TabIndex = 0
    Me.LogoPictureBox.TabStop = False
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Label1.Location = New System.Drawing.Point(224, 18)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(66, 20)
    Me.Label1.TabIndex = 6
    Me.Label1.Text = "ADMIN"
    '
    'Button1
    '
    Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Button1.Location = New System.Drawing.Point(337, 226)
    Me.Button1.Name = "Button1"
    Me.Button1.Size = New System.Drawing.Size(115, 24)
    Me.Button1.TabIndex = 7
    Me.Button1.Text = "Login As Donor"
    Me.Button1.UseVisualStyleBackColor = True
    '
    'LoginAdmin
    '
    Me.AcceptButton = Me.btnOk
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.BackColor = System.Drawing.Color.Snow
    Me.CancelButton = Me.btnCancel
    Me.ClientSize = New System.Drawing.Size(464, 262)
    Me.Controls.Add(Me.Button1)
    Me.Controls.Add(Me.Label1)
    Me.Controls.Add(Me.btnCancel)
    Me.Controls.Add(Me.btnOk)
    Me.Controls.Add(Me.txtPass)
    Me.Controls.Add(Me.txtUser)
    Me.Controls.Add(Me.PasswordLabel)
    Me.Controls.Add(Me.UsernameLabel)
    Me.Controls.Add(Me.LogoPictureBox)
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "LoginAdmin"
    Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
    Me.Text = "LoginAdmin"
    CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub

  Friend WithEvents Label1 As Label
  Friend WithEvents Button1 As Button
End Class
