Public Class Form1
  Private Sub BtnAdmin_Click(sender As Object, e As EventArgs) Handles btnAdmin.Click
    LoginAdmin.Show()
  End Sub

  Private Sub BtnDonor_Click(sender As Object, e As EventArgs) Handles btnDonor.Click
    LoginDonor.Show()

  End Sub
End Class
