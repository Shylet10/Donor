﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
<Global.System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1726")> _
Partial Class LoginDonor
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
      If disposing AndAlso components IsNot Nothing Then
        components.Dispose()
      End If
    Finally
      MyBase.Dispose(disposing)
    End Try
  End Sub
  Friend WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
  Friend WithEvents UsernameLabel As System.Windows.Forms.Label
  Friend WithEvents PasswordLabel As System.Windows.Forms.Label
  Friend WithEvents txtUser As System.Windows.Forms.TextBox
  Friend WithEvents txtPass As System.Windows.Forms.TextBox
  Friend WithEvents OK As System.Windows.Forms.Button
  Friend WithEvents Cancel As System.Windows.Forms.Button

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
    Me.UsernameLabel = New System.Windows.Forms.Label()
    Me.PasswordLabel = New System.Windows.Forms.Label()
    Me.txtUser = New System.Windows.Forms.TextBox()
    Me.txtPass = New System.Windows.Forms.TextBox()
    Me.OK = New System.Windows.Forms.Button()
    Me.Cancel = New System.Windows.Forms.Button()
    Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
    Me.CheckBoxSP = New System.Windows.Forms.CheckBox()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
    Me.Button1 = New System.Windows.Forms.Button()
    Me.Label2 = New System.Windows.Forms.Label()
    CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'UsernameLabel
    '
    Me.UsernameLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.UsernameLabel.Location = New System.Drawing.Point(163, 56)
    Me.UsernameLabel.Name = "UsernameLabel"
    Me.UsernameLabel.Size = New System.Drawing.Size(220, 23)
    Me.UsernameLabel.TabIndex = 0
    Me.UsernameLabel.Text = "&User name"
    Me.UsernameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
    '
    'PasswordLabel
    '
    Me.PasswordLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.PasswordLabel.Location = New System.Drawing.Point(163, 105)
    Me.PasswordLabel.Name = "PasswordLabel"
    Me.PasswordLabel.Size = New System.Drawing.Size(220, 23)
    Me.PasswordLabel.TabIndex = 2
    Me.PasswordLabel.Text = "&Password"
    Me.PasswordLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
    '
    'txtUser
    '
    Me.txtUser.Location = New System.Drawing.Point(163, 82)
    Me.txtUser.Name = "txtUser"
    Me.txtUser.Size = New System.Drawing.Size(220, 20)
    Me.txtUser.TabIndex = 1
    '
    'txtPass
    '
    Me.txtPass.Location = New System.Drawing.Point(163, 131)
    Me.txtPass.Name = "txtPass"
    Me.txtPass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
    Me.txtPass.Size = New System.Drawing.Size(220, 20)
    Me.txtPass.TabIndex = 3
    '
    'OK
    '
    Me.OK.Location = New System.Drawing.Point(163, 210)
    Me.OK.Name = "OK"
    Me.OK.Size = New System.Drawing.Size(94, 23)
    Me.OK.TabIndex = 4
    Me.OK.Text = "&OK"
    '
    'Cancel
    '
    Me.Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Cancel.Location = New System.Drawing.Point(299, 210)
    Me.Cancel.Name = "Cancel"
    Me.Cancel.Size = New System.Drawing.Size(94, 23)
    Me.Cancel.TabIndex = 5
    Me.Cancel.Text = "&Cancel"
    '
    'LogoPictureBox
    '
    Me.LogoPictureBox.Image = Global.db_prac.My.Resources.Resources.bloodV
    Me.LogoPictureBox.Location = New System.Drawing.Point(0, 0)
    Me.LogoPictureBox.Name = "LogoPictureBox"
    Me.LogoPictureBox.Size = New System.Drawing.Size(135, 334)
    Me.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
    Me.LogoPictureBox.TabIndex = 0
    Me.LogoPictureBox.TabStop = False
    '
    'CheckBoxSP
    '
    Me.CheckBoxSP.AutoSize = True
    Me.CheckBoxSP.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.CheckBoxSP.Location = New System.Drawing.Point(163, 166)
    Me.CheckBoxSP.Name = "CheckBoxSP"
    Me.CheckBoxSP.Size = New System.Drawing.Size(114, 19)
    Me.CheckBoxSP.TabIndex = 6
    Me.CheckBoxSP.Text = "Show Password"
    Me.CheckBoxSP.UseVisualStyleBackColor = True
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Label1.Location = New System.Drawing.Point(236, 20)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(85, 24)
    Me.Label1.TabIndex = 7
    Me.Label1.Text = "DONOR"
    '
    'LinkLabel1
    '
    Me.LinkLabel1.AutoSize = True
    Me.LinkLabel1.Cursor = System.Windows.Forms.Cursors.Hand
    Me.LinkLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.LinkLabel1.Location = New System.Drawing.Point(278, 297)
    Me.LinkLabel1.Name = "LinkLabel1"
    Me.LinkLabel1.Size = New System.Drawing.Size(232, 16)
    Me.LinkLabel1.TabIndex = 8
    Me.LinkLabel1.TabStop = True
    Me.LinkLabel1.Text = "Click Here to register as a donor"
    '
    'Button1
    '
    Me.Button1.Location = New System.Drawing.Point(224, 248)
    Me.Button1.Name = "Button1"
    Me.Button1.Size = New System.Drawing.Size(108, 23)
    Me.Button1.TabIndex = 9
    Me.Button1.Text = "Forgot Password?"
    Me.Button1.UseVisualStyleBackColor = True
    '
    'Label2
    '
    Me.Label2.AutoSize = True
    Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold)
    Me.Label2.Location = New System.Drawing.Point(184, 297)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(95, 16)
    Me.Label2.TabIndex = 10
    Me.Label2.Text = "No Account?"
    '
    'LoginDonor
    '
    Me.AcceptButton = Me.OK
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.BackColor = System.Drawing.Color.Snow
    Me.CancelButton = Me.Cancel
    Me.ClientSize = New System.Drawing.Size(520, 334)
    Me.Controls.Add(Me.Label2)
    Me.Controls.Add(Me.Button1)
    Me.Controls.Add(Me.LinkLabel1)
    Me.Controls.Add(Me.Label1)
    Me.Controls.Add(Me.CheckBoxSP)
    Me.Controls.Add(Me.Cancel)
    Me.Controls.Add(Me.OK)
    Me.Controls.Add(Me.txtPass)
    Me.Controls.Add(Me.txtUser)
    Me.Controls.Add(Me.PasswordLabel)
    Me.Controls.Add(Me.UsernameLabel)
    Me.Controls.Add(Me.LogoPictureBox)
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "LoginDonor"
    Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
    Me.Text = "LoginDonor"
    CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub

  Friend WithEvents CheckBoxSP As CheckBox
  Friend WithEvents Label1 As Label
  Friend WithEvents LinkLabel1 As LinkLabel
  Friend WithEvents Button1 As Button
  Friend WithEvents Label2 As Label
End Class
